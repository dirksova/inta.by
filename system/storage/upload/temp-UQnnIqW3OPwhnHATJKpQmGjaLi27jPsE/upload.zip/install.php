<?php
	$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "topstickers'";
	if (count($this->db->query($sql)->rows) == 0) { // if not installed
		$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "topstickers` (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			`topsticker_id` int(11),
			`name` char(100) DEFAULT NULL,
			`text` varchar(255),
			`bg_color` char(100) DEFAULT NULL,
			`status` tinyint(1) DEFAULT NULL,
			PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		$this->db->query($sql);

		$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "topstickers_product` (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			`product_id` int(11) NOT NULL,
			`topsticker_id` int(11) NOT NULL,
			PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		$this->db->query($sql); 
	}	